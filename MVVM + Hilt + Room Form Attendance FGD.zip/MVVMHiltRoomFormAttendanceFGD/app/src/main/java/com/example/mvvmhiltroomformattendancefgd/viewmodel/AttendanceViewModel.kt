package com.example.mvvmhiltroomformattendancefgd.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.mvvmhiltroomformattendancefgd.data.model.AttendanceModel
import com.example.mvvmhiltroomformattendancefgd.repository.AttendanceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AttendanceViewModel @Inject constructor(
    private val repository: AttendanceRepository
) : ViewModel() {

    val attendanceList = repository.getAll().asLiveData()

    fun addAttendance(
        name: String,
        phoneNumber: String,
        email: String,
        gender: String,
        skillSet: String,
        category: String
    ) {
        val attendance = AttendanceModel(
            name = name,
            phoneNumber = phoneNumber,
            email = email,
            gender = gender,
            skillSet = skillSet,
            category = category
        )
        viewModelScope.launch {
            repository.insert(attendance)
        }
    }
} 