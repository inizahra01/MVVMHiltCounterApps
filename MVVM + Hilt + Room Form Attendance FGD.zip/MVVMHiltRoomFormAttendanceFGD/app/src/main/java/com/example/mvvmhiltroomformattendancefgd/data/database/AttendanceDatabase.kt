package com.example.mvvmhiltroomformattendancefgd.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.mvvmhiltroomformattendancefgd.data.dao.AttendanceDao
import com.example.mvvmhiltroomformattendancefgd.data.model.AttendanceModel

@Database(entities = [AttendanceModel::class], version = 1, exportSchema = false)
abstract class AttendanceDatabase : RoomDatabase() {
    abstract fun attendanceDao(): AttendanceDao
} 