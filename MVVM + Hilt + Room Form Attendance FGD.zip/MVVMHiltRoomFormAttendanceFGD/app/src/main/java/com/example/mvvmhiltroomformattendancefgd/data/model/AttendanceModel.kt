package com.example.mvvmhiltroomformattendancefgd.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance")
data class AttendanceModel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val email: String,
    val gender: String,
    val skillSet: String,
    val category: String
) 