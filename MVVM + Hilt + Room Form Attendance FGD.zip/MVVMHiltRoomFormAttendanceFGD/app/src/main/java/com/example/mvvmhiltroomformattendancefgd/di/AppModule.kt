package com.example.mvvmhiltroomformattendancefgd.di

import android.content.Context
import androidx.room.Room
import com.example.mvvmhiltroomformattendancefgd.data.database.AttendanceDatabase
import com.example.mvvmhiltroomformattendancefgd.data.dao.AttendanceDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AttendanceDatabase {
        return Room.databaseBuilder(
            context,
            AttendanceDatabase::class.java,
            "attendance_database"
        ).build()
    }

    @Provides
    fun provideAttendanceDao(database: AttendanceDatabase): AttendanceDao {
        return database.attendanceDao()
    }
} 