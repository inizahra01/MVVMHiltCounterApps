package com.example.mvvmhiltroomformattendancefgd.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.mvvmhiltroomformattendancefgd.R
import com.example.mvvmhiltroomformattendancefgd.databinding.FragmentInputBinding
import com.example.mvvmhiltroomformattendancefgd.viewmodel.AttendanceViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InputFragment : Fragment() {
    private var _binding: FragmentInputBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AttendanceViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupCategoryDropdown()
        setupSubmitButton()
    }

    private fun setupCategoryDropdown() {
        val categories = arrayOf("Beginner", "Intermediate", "Expert")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, categories)
        binding.categoryAutoComplete.setAdapter(adapter)
    }

    private fun setupSubmitButton() {
        binding.submitButton.setOnClickListener {
            val name = binding.nameEditText.text.toString()
            val phone = binding.phoneEditText.text.toString()
            val email = binding.emailEditText.text.toString()
            val gender = when (binding.genderRadioGroup.checkedRadioButtonId) {
                R.id.maleRadioButton -> "Male"
                R.id.femaleRadioButton -> "Female"
                else -> ""
            }
            val skillSet = getSelectedSkills()
            val category = binding.categoryAutoComplete.text.toString()

            if (validateInput(name, phone, email, gender, category)) {
                viewModel.addAttendance(name, phone, email, gender, skillSet, category)
                clearForm()
                Toast.makeText(requireContext(), "Data saved successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getSelectedSkills(): String {
        val selectedSkills = mutableListOf<String>()
        if (binding.androidCheckBox.isChecked) selectedSkills.add("Android")
        if (binding.webCheckBox.isChecked) selectedSkills.add("Web")
        if (binding.iosCheckBox.isChecked) selectedSkills.add("iOS")
        return selectedSkills.joinToString(", ")
    }

    private fun validateInput(
        name: String,
        phone: String,
        email: String,
        gender: String,
        category: String
    ): Boolean {
        var isValid = true

        if (name.isBlank()) {
            binding.nameLayout.error = "Name is required"
            isValid = false
        } else {
            binding.nameLayout.error = null
        }

        if (phone.isBlank()) {
            binding.phoneLayout.error = "Phone number is required"
            isValid = false
        } else {
            binding.phoneLayout.error = null
        }

        if (email.isBlank()) {
            binding.emailLayout.error = "Email is required"
            isValid = false
        } else {
            binding.emailLayout.error = null
        }

        if (gender.isBlank()) {
            Toast.makeText(requireContext(), "Please select gender", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        if (category.isBlank()) {
            binding.categoryLayout.error = "Category is required"
            isValid = false
        } else {
            binding.categoryLayout.error = null
        }

        return isValid
    }

    private fun clearForm() {
        binding.nameEditText.text?.clear()
        binding.phoneEditText.text?.clear()
        binding.emailEditText.text?.clear()
        binding.genderRadioGroup.clearCheck()
        binding.androidCheckBox.isChecked = false
        binding.webCheckBox.isChecked = false
        binding.iosCheckBox.isChecked = false
        binding.categoryAutoComplete.text?.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 