package com.example.mvvmhiltroomformattendancefgd.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.mvvmhiltroomformattendancefgd.data.model.AttendanceModel
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(attendance: AttendanceModel)

    @Query("SELECT * FROM attendance")
    fun getAll(): Flow<List<AttendanceModel>>
} 