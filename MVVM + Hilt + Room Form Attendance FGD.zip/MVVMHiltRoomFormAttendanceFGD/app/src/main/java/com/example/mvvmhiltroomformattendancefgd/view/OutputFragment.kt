package com.example.mvvmhiltroomformattendancefgd.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.mvvmhiltroomformattendancefgd.databinding.FragmentOutputBinding
import com.example.mvvmhiltroomformattendancefgd.viewmodel.AttendanceViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class OutputFragment : Fragment() {
    private var _binding: FragmentOutputBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AttendanceViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOutputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.attendanceList.observe(viewLifecycleOwner) { attendanceList ->
            val output = buildString {
                attendanceList.forEachIndexed { index, attendance ->
                    append("Participant ${index + 1}:\n")
                    append("Name: ${attendance.name}\n")
                    append("Phone: ${attendance.phoneNumber}\n")
                    append("Email: ${attendance.email}\n")
                    append("Gender: ${attendance.gender}\n")
                    append("Skills: ${attendance.skillSet}\n")
                    append("Category: ${attendance.category}\n")
                    append("\n")
                }
            }
            binding.outputTextView.text = if (output.isNotEmpty()) output else "No participants yet"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 