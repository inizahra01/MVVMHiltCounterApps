package com.example.mvvmhiltroomformattendancefgd

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyApps : Application() 